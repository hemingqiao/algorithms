
import CacheRoute from './components/CacheRoute'
import CacheSwitch from './components/CacheSwitch'

export default CacheRoute;
export {
  CacheRoute,
    CacheSwitch
};

export {
  dropByCacheKey,
  refreshByCacheKey,
  getCachingKeys,
  clearCache,
  getCachingComponents
} from './core/manager'
export { useDidCache, useDidRecover } from './core/context'
