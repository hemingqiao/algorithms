import React from "react";
import { useLocation, Link } from "react-router-dom";
import {
    CacheSwitch,
    CacheRoute,
    useDidCache,
    useDidRecover,
    dropByCacheKey,
    clearCache,
    getCachingKeys
} from "./react-router-cache";

import "./styles.css";

window.dropByCacheKey = dropByCacheKey;
window.clearCache = clearCache;
window.getCachingKeys = getCachingKeys;

function Counter() {
    const [count, setCount] = React.useState(0);

    return (
        <div>
            count: {count}
            <button onClick={() => setCount(count + 1)}>add</button>
        </div>
    );
}

function List() {
    useDidCache(() => {
        console.log("List did cache");
    });

    useDidRecover(() => {
        console.log("List did recover");
    });

    return (
        <div style={{ height: "90vh", overflow: "auto" }}>
            {Array(100)
                .fill("")
                .map((item, idx) => (
                    <div key={idx}>
                        to{" "}
                        <Link
                            to={{
                                pathname: `/item`,
                                search: `?id=${idx}`,
                                state: {
                                    id: idx
                                }
                            }}
                        >
                            Item {idx}
                        </Link>
                    </div>
                ))}
        </div>
    );
}

function Item() {
    const location = useLocation();
    useDidCache(() => {
        console.log(`Item ${location.search} did cache`);
    });

    useDidRecover(() => {
        console.log(`Item ${location.search} did recover`);
    });

    return (
        <div>
            Item {location.search} <Counter />
            <p>state: {location.state?.id}</p>
        </div>
    );
}

export default function App() {
    return (
        <CacheSwitch>
            <CacheRoute
                exact
                path="/"
                component={List}
                when="always"
                cacheKey="list"
            />
            <CacheRoute
                exact
                path="/item"
                component={Item}
                cacheKey="item"
                when="always"
                multiple
            />
        </CacheSwitch>
    );
}
